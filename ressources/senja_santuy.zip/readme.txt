Senja Santuy font is 100% free. You can use it for personal or commercial purposes.

Visit my store: https://www.creativefabrica.com/designer/zuzulgo-studio/ref/143836/


If you want to donate click here https://www.paypal.me/zuzulgo
I really appreciate your donations.

Thank you.